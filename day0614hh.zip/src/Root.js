import React from "react";
import './App.css';
import {BrowserRouter} from 'react-router-dom'; //react-router-dom의 BrowserRouter라는 클래스
import RouterMain from "./RouterMain";

const Root=()=>{
    return (
        <BrowserRouter>
            <RouterMain/>
        </BrowserRouter>
    )
}

export default Root;