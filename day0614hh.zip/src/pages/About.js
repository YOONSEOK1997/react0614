import React from "react";
import '../App.css';
import {useParams} from 'react-router-dom';
const About=()=>{
    const {name}=useParams(); //useParams로부터 name을 가져왕
    
    return (
        <div>
          <h3 className="hello">안녕하세요 제 이름은  {name==null?'마블리':name} 입니다 </h3>
        </div>
    )
}

export default About;