import React from "react";
import '../App.css';
import {} from 'react-router-dom';

const Home=()=>{
    return (
        <div>
          <button type="button" className="btn btn-danger"
          onClick={()=>{navigator("/about");}}>About</button>
          <button type="button" className="btn btn-info"
          onClick={()=>{navigator("/about/순자");}}>About2</button>
          <button type="button" className="btn btn-success"
          onClick={()=>{navigator("/food/11/12");}}>점심메뉴</button>
          <button type="button" className="btn btn-warning"
          onClick={()=>{navigator("/food//8/9");}}>저녁메뉴</button>
          
          
        </div>
    )
}

export default Home;