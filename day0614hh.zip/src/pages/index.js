export {default as Home} from './Home'; //홈이라는 이름으로 엑스포트하게따
export {default as About} from './About'; //About이라는 이름으로 "" 
                                           //export default는 거기서 지정된 이름으로 가져와야해                         
export {default as Food} from './Food';