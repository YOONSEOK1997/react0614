import React from "react";
import '../App.css';
import {useParams} from 'react-router-dom';
const Food=()=>{
    const {food1,food2}=useParams(); 

    return (
        <div>
          <h3>오늘식사메뉴 </h3>
        <img alt='' src={`../../image/${food1}.jpg`}/>
        <img alt='' src={`../../image/${food2}.jpg`}/>
        </div>
    )
}

export default Food;