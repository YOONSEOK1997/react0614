import React from "react";
import '../App.css';
import {NavLink} from 'react-router-dom';

const Menu=()=>{
    return (
        <div>
            <ul className="menu">
                <li><NavLink to='/'>Home</NavLink></li>
                <li><NavLink to='/about'>About</NavLink></li>
                <li><NavLink to='/about/2'>About2</NavLink></li>
                <li><NavLink to='/login'>로그인</NavLink></li>
                <li><NavLink to='/food/2/3'>점심메뉴</NavLink></li>
                <li><NavLink to='/food/1/4'>저녁메뉴</NavLink></li>
            </ul>
        </div>
    )
}

export default Menu;